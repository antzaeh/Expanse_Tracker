//GUI.java alku
package java_harjoitustyo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
//GUI.java aukaisee ensimm�isen FJramen mist� l�hdemme ajamaan ohjelmaa
@SuppressWarnings("serial")
public class GUI extends Menot implements ActionListener {

	protected static JPanel panel;

	protected static JButton button;
	protected static JButton button1;
	protected static JButton button2;
	protected static JButton button3;
	protected static JButton button4;

	public static void main(String args[]) {

		new GUI();

	}

	public GUI() {

		JFrame frame = new JFrame();
		button = new JButton("Uusi meno");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//Nappia painamalla kutsutaan GuiMethod.java metodia createFrameUusi
				GuiMethod.createFrameUusi();
			}
		});
		button1 = new JButton("P�iv�n menot");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Nappia painamalla kutsutaan GuiMethod.java metodia createFrameMenot
				GuiMethod.createFrameMenot();
			}
		});
		button2 = new JButton("Hae p�iv�nm��r�ll�");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Nappia painamalla kutsutaan GuiMethod.java metodia createFrameHaepvm
				GuiMethod.createFrameHaepvm();
			}
		});
		button3 = new JButton("Pylv�skaavio");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Nappia painamalla kutsutaan GuiMethod.java metodia createFrameKaavio
				GuiMethod.createFrameKaavio();
			}
		});
		button4 = new JButton("Lue/Tallenna tiedosto");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Nappia painamalla kutsutaan GuiMethod.java metodia createFrameTiedosto
				GuiMethod.createFrameTiedosto();
			}
		});

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100));
		panel.setLayout(new GridLayout(0, 1));
		panel.add(button);
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.add(button4);

		frame.add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("MenoLaskuri");
		frame.pack();
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
//GUI.java loppu