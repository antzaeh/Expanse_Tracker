//MenoLaskuri alku
package java_harjoitustyo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

@SuppressWarnings("serial")
public class MenoLaskuri extends Menot implements Serializable {

	static String viesti = "Valitse numero\n1. Sy�t� uusi meno 2. N�yt� p�iv�n menot 3. Hae menoja p�iv�nm��r�ll�"
			+ " 4. N�yt� yhteenveto pylv�skaaviona 5. Lue/tallenna menoja tiedostoon X. Lopetus";
	static MenoLaskuri meno = new MenoLaskuri();

	public static void main(String[] args) {
		System.out.println(viesti);

		Scanner s = new Scanner(System.in);
		String input = s.nextLine().toLowerCase();

		while (input != "x") {
			switch (input) {
			case "1":
				uusiMaksu();
				System.out.println(viesti);
				input = s.nextLine().toLowerCase();
				break;
			case "2":
				laskeMenot();
				System.out.println(viesti);
				input = s.nextLine().toLowerCase();
				break;
			case "3":
				paivaMaaraMenot(menolista);
				System.out.println(viesti);
				input = s.nextLine().toLowerCase();
				break;
			case "4":
				// TODO BarChart();
				System.out.println(viesti);
				input = s.nextLine().toLowerCase();
				break;
			case "5":
				tiedosto();
				System.out.println(viesti);
				input = s.nextLine().toLowerCase();
				break;
			case "x":
				System.exit(0);
			}
		}
		
	}

	public static void uusiMaksu() {
		String menoViesti = "Valitse kategoria:\n1. Auto 2. Lasku 3. Kauppa 4. Viihde 5. Muu 0. Paluu";
		System.out.println("Sy�t� p�iv�nm��r� muodossa pp.kk.vv");

		Scanner s = new Scanner(System.in);
		String pvm = s.nextLine();

		System.out.println(menoViesti);

		Scanner s1 = new Scanner(System.in);
		String input = s1.nextLine().toLowerCase();

		while (input != "x") {
			switch (input) {
			case "1": {
				String meno = "Auto";
				uusiMeno(pvm, meno);
				System.out.println(menoViesti);
				input = s.nextLine().toLowerCase();
				break;
			}
			case "2": {
				String meno = "Lasku";
				uusiMeno(pvm, meno);
				System.out.println(menoViesti);
				input = s.nextLine().toLowerCase();
				break;
			}

			case "3": {
				String meno = "Kauppa";
				uusiMeno(pvm, meno);
				System.out.println(menoViesti);
				input = s.nextLine().toLowerCase();
				break;
			}
			case "4": {
				String meno = "Viihde";
				uusiMeno(pvm, meno);
				System.out.println(menoViesti);
				input = s.nextLine().toLowerCase();
				break;
			}

			case "5": {
				String meno = "Muu";
				uusiMeno(pvm, meno);
				System.out.println(menoViesti);
				input = s.nextLine().toLowerCase();
				break;
			}

			case "0": {
				return;
			}
			default:
				System.out.println("Virheellinen valinta");
				System.out.println(menoViesti);
				break;
			}
		}
		
	}

	@SuppressWarnings("resource")
	public static void uusiMeno(String pvm, String meno) {
		String kategoria = meno;
		System.out.println("Valittu kategoria " + kategoria);

		System.out.println("Hinta. Sentit pilkulla");
		Scanner s1 = new Scanner(System.in);
		double hinta = s1.nextDouble();

		System.out.println("Kuvaus");
		Scanner s2 = new Scanner(System.in);
		String kuvaus = s2.nextLine();

		menolista.add(new Menot(kategoria, hinta, kuvaus, pvm));
		return;

	}

	public static void laskeMenot() {

		double menot = 0;
		for (int i = 0; i < menolista.size(); i++) {
			menot += menolista.get(i).getHinta();
		}
		System.out.println("Menot yhteens�: " + menot);
		System.out.println(menolista);
	}

	private static void paivaMaaraMenot(ArrayList<Menot> menolista) {
		System.out.println("Etsi menoja p�iv�nm��r�ll� \n" + "Sy�t� p�iv�nm��r� muodossa pp.kk.vvvv");
		Scanner s = new Scanner(System.in);
		String etsi = s.nextLine();

		for (int i = 0; i < menolista.size(); i++) {
			if (menolista.get(i).getPvm().contains(etsi)) {
				System.out.println(menolista.get(i));
			} else {
				System.out.println("Ei menoja haetulla p�iv�nm��r�ll�");
			}
		}
	
	}

	private static void tiedosto() {
		System.out.println("1. Luetaan tiedostosta 2. Tallenetaan tiedostoon");
		Scanner s = new Scanner(System.in);
		String input = s.nextLine().toLowerCase();

		switch (input) {
		case "1":
			lueTiedosto();
			break;
		case "2":
			tallennaTiedosto();
			break;
		default:
			System.out.println("Virheellinen sy�te");
			break;
		}
		
	}

	@SuppressWarnings("unchecked")
	static void lueTiedosto() {
		System.out.println("Anna tiedoston polku");
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		String tiedosto = s.nextLine();
		try (ObjectInputStream file_in = new ObjectInputStream(new FileInputStream(tiedosto))) {
			menolista = (ArrayList<Menot>) file_in.readObject();
			file_in.close();
		} catch (Exception e) {
			System.out.println("Ongelmia " + tiedosto + " kanssa");
			e.printStackTrace();
			
		}
	}

	private static void tallennaTiedosto() {
		System.out.println("Anna polku tallennettavaan tiedostoon");
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		String tiedosto = s.nextLine();
		try {
			FileOutputStream fos = new FileOutputStream(tiedosto);
			ObjectOutputStream file_out = new ObjectOutputStream(fos);
			file_out.writeObject(menolista);
			fos.close();
			file_out.close();
		}

		catch (Exception e) {
			System.out.println("Ongelmia " + tiedosto);
			e.printStackTrace();
			
		}
	}
}
//MenoLaskuri loppu