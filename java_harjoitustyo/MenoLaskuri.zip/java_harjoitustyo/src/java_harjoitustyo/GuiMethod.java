//GuiMethod.java alku
package java_harjoitustyo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

@SuppressWarnings("serial")
//Metodit mit� ohjelmassa k�ytett��n
public class GuiMethod extends GUI {

	static double summaAuto = 0;
	static double summaLasku = 0;
	static double summaKauppa = 0;
	static double summaViihde = 0;
	static double summaMuu = 0;
//createFrameUusi metodilla luodaan uusi meno ja tallennetaan se arraylistaan
	public static void createFrameUusi() {
		JFrame frame = new JFrame();
		//Teksikent�t mihin kirjoitetaan p�iv�nm��r�, summa ja kuvaus oliota varten
		JLabel pvm = new JLabel("P�iv�nm��r� muodossa pp.kk.vvvv");
		JTextField field = new JTextField();
		JLabel kuvaus = new JLabel("Kuvaus");
		JTextField field1 = new JTextField();
		JLabel summa = new JLabel("Summa. Sentit pisteell�");
		TextField field2 = new TextField();
		
		button = new JButton("Auto");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String kategoria = "Auto";
				String pvm = field.getText();
				String kuvaus = field2.getText();
				double hinta = Double.parseDouble(field1.getText());
				menolista.add(new Menot(kategoria, hinta, kuvaus, pvm));

			}
		});
		button1 = new JButton("Lasku");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Kun nappulaa painetaan kategoriaksi asetetaan lasku, muut tiedot otetaanyll�olevasta teksikent�st� 
				//luodaan olio ja tallennetaan se arraylistaan
				String kategoria = "Lasku";
				String pvm = field.getText();
				String kuvaus = field2.getText();
				double hinta = Double.parseDouble(field1.getText());
				menolista.add(new Menot(kategoria, hinta, kuvaus, pvm));

			}
		});
		button2 = new JButton("Kauppa");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Kun nappulaa painetaan kategoriaksi asetetaan kauppa, muut tiedot otetaanyll�olevasta teksikent�st� 
				//luodaan olio ja tallennetaan se arraylistaan
				String kategoria = "Kauppa";
				String pvm = field.getText();
				String kuvaus = field2.getText();
				double hinta = Double.parseDouble(field1.getText());
				menolista.add(new Menot(kategoria, hinta, kuvaus, pvm));

			}
		});
		button3 = new JButton("Viihde");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Kun nappulaa painetaan kategoriaksi asetetaan viihde, muut tiedot otetaanyll�olevasta teksikent�st� 
				//luodaan olio ja tallennetaan se arraylistaan
				String kategoria = "Viihde";
				String pvm = field.getText();
				String kuvaus = field2.getText();
				double hinta = Double.parseDouble(field1.getText());
				menolista.add(new Menot(kategoria, hinta, kuvaus, pvm));

			}
		});
		button4 = new JButton("Muu");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Kun nappulaa painetaan kategoriaksi asetetaan muu, muut tiedot otetaanyll�olevasta teksikent�st� 
				//luodaan olio ja tallennetaan se arraylistaan
				String kategoria = "Muu";
				String pvm = field.getText();
				String kuvaus = field2.getText();
				double hinta = Double.parseDouble(field1.getText());
				menolista.add(new Menot(kategoria, hinta, kuvaus, pvm));

			}
		});
		//Luodaan paneeli ja lis�t��n siihen tarvittavat kent�t/napit
		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100));
		panel.setLayout(new GridLayout(0, 1));
		panel.add(pvm);
		panel.add(field);
		panel.add(summa);
		panel.add(field1);
		panel.add(kuvaus);
		panel.add(field2);
		panel.add(button);
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.add(button4);

		frame.add(panel, BorderLayout.CENTER);

		frame.setTitle("Lis�� uusi meno");
		frame.pack();
		frame.setVisible(true);

	}
//createFrameMenot metodilla tarkastellaan nykyisen istunnon menoja
	public static void createFrameMenot() {
		
		JFrame frame = new JFrame();
		//Loopataan arraylista ett� saamme kaikkien menojen yhteenlasketun summan
		double menot = 0;
		for (int i = 0; i < menolista.size(); i++) {
			menot += menolista.get(i).getHinta();
		}
		//Luodaan paneeli, textarea sek� labelit joissa n�ytet��n tietoa
		JTextArea menoText = new JTextArea();
		JPanel panel = new JPanel();
		JLabel istunto = new JLabel("T�ll� istunnolla kirjatut menot");
		JLabel yhteensa = new JLabel("Istunnon menot yhteens�:  " + menot);
		//Tulostetaan kaikki istunnon menot toString metodilla
		for (int i = 0; i < menolista.size(); i++) {
			menoText.append(menolista.get(i).toString() + "\n");
		}

		panel.setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100));
		panel.setLayout(new BorderLayout());
		panel.add(istunto, BorderLayout.NORTH);
		menoText.setWrapStyleWord(true);
		panel.add(menoText, BorderLayout.CENTER);
		panel.add(yhteensa, BorderLayout.SOUTH);
		frame.add(panel);
		frame.setTitle("T�n��n kirjatut menot");
		frame.pack();
		frame.setVisible(true);

	}
//createFrameHaePvm metodilla etsit��n menoja tietyn p�iv�nm��r�n mukaan
	static void createFrameHaepvm() {

		JFrame frame = new JFrame();
		//Tekstikentt� johon p�iv�nm��r� kirjoitetaan
		JLabel etsipvm = new JLabel("Sy�t� p�iv�nm��r� pp.kk.vv");
		JTextField etsi = new JTextField();

		button = new JButton("Hae");
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Nappia painamalla otetaan tekstikent�st� string pvm
				String pvm = etsi.getText();
				JFrame frame = new JFrame();
				JTextArea pvmText = new JTextArea();
				double menot = 0;
				//string pvm k�ytet��n if lauseessa, ett� saadaan vain sen p�iv�nm��r�n menot yhteen laskettuna
				for (int i = 0; i < menolista.size(); i++) {
					if (menolista.get(i).getPvm().contains(pvm)) {
					menot += menolista.get(i).getHinta();
				}
				}
				JLabel yhteensa = new JLabel(pvm + " menot yhteens�: " + menot);
				panel = new JPanel();

				for (int i = 0; i < menolista.size(); i++) {
					//Tulostetaan kyseisen p�iv�n menot
					if (menolista.get(i).getPvm().contains(pvm)) {
						pvmText.append(menolista.get(i).toString() + "\n");
					}
						JLabel pvmLabel = new JLabel("Menot " + pvm + " ovat");
						panel.setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100));
						panel.setLayout(new BorderLayout());
						panel.add(pvmLabel, BorderLayout.NORTH);
						pvmText.setWrapStyleWord(true);
						panel.add(pvmText, BorderLayout.CENTER);
						panel.add(yhteensa, BorderLayout.SOUTH);
						frame.add(panel);
						frame.setTitle("Menot " + pvm + " p�iv�nm��r�ll�");
						frame.pack();
						frame.setVisible(true);
					
				}
			}

		});
		
		panel = new JPanel();
		panel.add(etsipvm);
		panel.add(etsi);
		panel.add(button);

		panel.setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100));
		panel.setLayout(new GridLayout(0, 1));
		frame.add(panel, BorderLayout.PAGE_START);

		frame.setTitle("Menot p�iv�nm��r�ll�");
		frame.pack();
		frame.setVisible(true);

	}
	//createFrameKaavio metodilla n�ytet��n menot kategorioittain kaaviona
	static void createFrameKaavio() {
		
		//Lasketaan jokaisen kategorian menot yhteens�
		for (int i = 0; i < menolista.size(); i++) {

			if (menolista.get(i).getKategoria().contains("Auto")) {
				summaAuto += menolista.get(i).getHinta();

			}
		}

		for (int i = 0; i < menolista.size(); i++) {

			if (menolista.get(i).getKategoria().contains("Lasku")) {
				summaLasku += menolista.get(i).getHinta();

			}
		}

		for (int i = 0; i < menolista.size(); i++) {

			if (menolista.get(i).getKategoria().contains("Kauppa")) {
				summaKauppa += menolista.get(i).getHinta();

			}
		}

		for (int i = 0; i < menolista.size(); i++) {

			if (menolista.get(i).getKategoria().contains("Viihde")) {
				summaViihde += menolista.get(i).getHinta();

			}
		}

		for (int i = 0; i < menolista.size(); i++) {

			if (menolista.get(i).getKategoria().contains("Muu")) {
				summaMuu += menolista.get(i).getHinta();

			}
		}
		//Luodaan labelit kategorioille
		JFrame frame = new JFrame();
		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(200, 200, 200, 200));
		panel.setLayout(new BorderLayout(1, 0));
		JLabel label = new JLabel("Auto " + summaAuto);
		JLabel label1 = new JLabel("Lasku " + summaLasku);
		JLabel label2 = new JLabel("Kauppa " + summaKauppa);
		JLabel label3 = new JLabel("Viihde " + summaViihde);
		JLabel label4 = new JLabel("Muu " + summaMuu);
		JLabel label5 = new JLabel ("Pylv�skaavio");
		//Asetetaan labelin paikka sek� leveydeksi yhteenlaskettu kategorian summma
		//Taidot eiv�t riitt�neet oikeaan pylv�skaavioon
		label.setBounds(30,30, (int) summaAuto,30);
		label1.setBounds(30,60,(int) summaLasku,30);
		label2.setBounds(30,90,(int) summaKauppa,30);
		label3.setBounds(30, 120,(int) summaViihde,30);
		label4.setBounds(30, 150,(int) summaMuu,30);
		
		Border border = BorderFactory.createLineBorder(Color.BLUE, 4);
		Border border1 = BorderFactory.createLineBorder(Color.RED, 4);
		Border border2 = BorderFactory.createLineBorder(Color.GREEN, 4);
		Border border3 = BorderFactory.createLineBorder(Color.BLACK, 4);
		Border border4 = BorderFactory.createLineBorder(Color.PINK, 4);
		label.setBorder(border);
		label1.setBorder(border1);
		label2.setBorder(border2);
		label3.setBorder(border3);
		label4.setBorder(border4);
		
		panel.add(label);
		panel.add(label1);
		panel.add(label2);
		panel.add(label3);
		panel.add(label4);
		panel.add(label5);
		frame.add(panel);

		frame.setTitle("Pylv�skaavio kategorioittain");
		frame.pack();
		frame.setVisible(true);
	}
//createFrameTiedosto joko luetaan tai tallennetaan tiedosto
	static void createFrameTiedosto() {
		JFrame frame = new JFrame();
		button = new JButton("Lue tiedosto");
		button.addActionListener(new ActionListener() {
			//Nappia painamalla siirryt��n metodiin readTiedosto
			public void actionPerformed(ActionEvent e) {
				try {
					readTiedosto();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});

		button1 = new JButton("Tallenna tiedosto");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Nappia painamalla siirryt��n metodiin saveTiedosto
				try {
					saveFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100));
		panel.setLayout(new GridLayout(0, 1));
		panel.add(button);
		panel.add(button1);

		frame.add(panel, BorderLayout.CENTER);

		frame.setTitle("Lue/Tallenna tiedosto");
		frame.pack();
		frame.setVisible(true);

	}
//readTiedosto metodilla luetaan tiedosto tietokoneelta
	@SuppressWarnings("unchecked")
	static void readTiedosto() throws IOException {
		//JFileChoose avaa file explorerin, josta haetaan tiedosto
		JFileChooser fc = new JFileChooser();
		//Vakiona exploreriin aukea c asema
		fc.setCurrentDirectory(new File("c:\\"));
		int resp = fc.showOpenDialog(null);

		if (resp == JFileChooser.APPROVE_OPTION) {
			//File fileen tallennetaan paikka mist� tiedosto halutaan avata
			File file = new File(fc.getSelectedFile().getAbsolutePath());
			//ObjectInputStream avaa tiedoston ja tallentaa sen arraylistaan
			try (ObjectInputStream file_in = new ObjectInputStream(new FileInputStream(file))) {
				menolista = (ArrayList<Menot>) file_in.readObject();
				file_in.close();
			} catch (Exception e) {
				System.out.println("Ongelmia " + file + " kanssa");
				e.printStackTrace();
			}
		}
	}
//saveFile metodilla tallennetaan tiedosto
	static void saveFile() throws IOException {
		//JFileChoose avaa file explorerin, josta valitaan tallennuspaikka
		JFileChooser fc = new JFileChooser();
		fc.setCurrentDirectory(new File("c:\\"));
		//Vakiona exploreriin aukea c asema
		int resp = fc.showSaveDialog(null);

		if (resp == JFileChooser.APPROVE_OPTION) {
			//File fileen tallennetaan paikka minne tiedosto halutaan tallentaa
			File file = new File(fc.getSelectedFile().getAbsolutePath());
			try {
				FileOutputStream fos = new FileOutputStream(file);
				//FileOutputStream sek� ObjectOutputStream tallentavat tiedoston
				ObjectOutputStream file_out = new ObjectOutputStream(fos);
				file_out.writeObject(menolista);
				fos.close();
				file_out.close();
			}

			catch (Exception e) {
				System.out.println("Problems with " + file);
				e.printStackTrace();
			}
		}
	}

}
//GuiMethod.java loppu